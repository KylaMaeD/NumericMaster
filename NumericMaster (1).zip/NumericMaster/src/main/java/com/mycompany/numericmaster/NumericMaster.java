package com.mycompany.numericmaster;

// Class that contains main method
public class NumericMaster {

    
    public static void main(String[] args) {
        
        // Open the main frame to begin the program
        new Main().setVisible(true);
    }
}
